<!-- div outside -->

<div class="containerpage7">
  <p style="font-size:12px; color:#CCCBCA;">
    <a style="color:#CCCBCA;" href="<?=base_url();?>home">home</a>
    <a style="color:#CCCBCA;" href="<?=base_url();?>login"> > Login & Register</a>
    </p>
  </div>

<!-- Start Form -->



  <div class="container-fluid">
  <div class="row">
    <main class="col-sm-8 ml-sm-auto col-md-9 pt-3" role="main">
<!-- main content -->
    <div class="row">
    <div class="col-md-6" style="padding-top:40px;">
        <h4 style="font-weight:bold;"><img src="<?=base_url()?>application/assets/images/arrow2.jpg" style="width:20px;"> &nbsp  Login & Register</h4><br><br>

        <p style="line-height:1%; font-size: 17px"> Your Account Login </p>
        <p style="font-size:12px;  ">* required field </p>

<!-- Form -->
      <form method="post" action="<?=base_url()?>logincheck" enctype="multipart/form-data">
      <div class="form-group col-md-6 mb-3"  style="margin-top:25px; margin-left:-13px;">
        <label for="loginEmail">E-mail Address *</label>
        <input type="email" class="form-control" name="loginEmail" id="loginEmail" aria-describedby="emailHelp" placeholder="Enter email">
        <small id="emailHelp" class="form-text text-muted">Your e-mail address from your account registerd.</small>
      </div>
      <div class="form-group col-md-6 mb-3" style="margin-left:-13px;">
        <label for="loginPassword">Password *</label>
        <input type="password" class="form-control" id="loginPassword" name="loginPassword" placeholder="Password">
      </div>
      <!-- <div class="form-check">
        <!-- <input type="checkbox" class="form-check-input" id="exampleCheck1"> -->
        <!-- <label class="form-check-label" for="exampleCheck1">Check me out</label> -->
      <!-- <button type="submit" class="btn btn-light" id="buttonSignIn" style="margin-left:3px; margin-top:10px;" >Sign in</button> -->
      <input type="submit" value="Sign in" class="btn btn-light" style="margin-left:0px;" >
    </form>


    </div>
<!-- Line middle -->

    <div class="VerticalLine">
    </div>

      <div class="col-md-6"><br>

<!-- register right-->

              <div style="margin-top:95px;">
               <p style="font-weight:bold; font-size: 17px">New Customers With</p>
               <p ><img src="<?=base_url()?>application/assets/images/Logo.jpg" style="width:32%; margin-left:-2%;"></p>
               <p style="font-size:14px; "> Creating your new account <br>
                 ,&nbsp just click below </p><br>
               <a href="<?=base_url();?>createaccount"><button type="submit" class="btn btn-light" id="buttonCreateAccount" style="margin-left:0px;" >Create Account</button></a>
              </div>

      </div>
<!-- end row-->
    </div>
<!-- end container  -->

</main>
</div>
</div>
