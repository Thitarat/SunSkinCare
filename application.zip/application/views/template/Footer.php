</body>

  <!-- Footer -->
  <br><br><br><br>
  <nav class="navbar navbar-expand-md navbar-dark  fixed-bottom " style="background-color: #FF9D00">
      <div class="container">
      <p class="text-white placeholders" style="font-size: 15px; margin-top:10px; ">@Copyright 2018 by Thitarat Lertnimittham & Yoonhye Jung. All rights reserved : prototype’s produced only for education</p>
      <!-- <p class = "float-right"><a href="#" class="text-info"> <i class="fa fa-chevron-up text-info" aria-hidden="true"></i>Back to top</a></p> -->
      <a href=""><img src="<?=base_url()?>application/assets/images/icon1.png" alt="icon1" style="width:35px; margin-right:-2px"></a>
      <a href=""><img src="<?=base_url()?>application/assets/images/icon2.png" alt="icon2" style="width:35px; margin-left:-57px"></a>
      <a href=""><img src="<?=base_url()?>application/assets/images/icon3.png" alt="icon3" style="width:35px; margin-left:-82px"></a>
      <a href=""><img src="<?=base_url()?>application/assets/images/icon4.png" alt="icon4" style="width:35px; margin-left:-106px"></a>
    </div>
  </nav>


  <!-- Script -->
  <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> -->
  <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->
  <!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha256-3edrmyuQ0w65f8gfBsqowzjJe2iM6n0nKciPUp8y+7E="crossorigin="anonymous"></script> -->
<!--
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script defer src="https://use.fontawesome.com/releases/v5.0.2/js/all.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" integrity="sha384-a5N7Y/aK3qNeh15eJKGWxsqtnX/wWdSZSKp+81YjTmS15nvnvxKHuzaWwXHDli+4" crossorigin="anonymous"></script>
  <script src='http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js'></script> -->


  <script type="text/javascript" src="<?=base_url('application/assets/src/'); ?>J_user.js"></script>

  <script type="text/javascript" src="<?=base_url()?>application/assets/js/modify.js"></script>

  <!-- filter search -->
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

</html>
