<!-- div outside -->

<div class="containerpage7">
  <p style="font-size:12px; color:#CCCBCA;">
    <a style="color:#CCCBCA;" href="<?=base_url();?>home">home</a>
    <a style="color:#CCCBCA;" href="<?=base_url();?>careproducts"> > Care Products</a>

    </p>
  </div>

<!-- Start Form -->



  <div class="container-fluid">
  <div class="row">
    <main class="col-sm-8 ml-sm-auto col-md-11 pt-3" role="main">
<!-- main content -->
    <div class="row">
    <div class="col-md-8" style="padding-top:40px;">
        <h4 style="font-weight:bold;"><img src="<?=base_url()?>application/assets/images/arrow2.jpg" style="width:20px;"> &nbsp Products</h4><br><br>

<!-- Title -->

<div class="col-md-18 mb-3" style="margin-top:10px;">
  <div>
  <h5 style="font-weight:bold;">Filter& Refine</h5></a>

  <div class="container-fluid" style="margin-left:-15px; margin-top:20px;">
      <div class="row">
  		<div class="col-xs-8 col-sm-3">
  			<div id="accordion" class="panel panel-primary behclick-panel">

  				<div class="panel-body" >
  					<div class="" >
  						<h5 class="panel-title">
  							<a data-toggle="collapse" href="#collapse0">
  								<i class="indicator fa fa-caret-down" aria-hidden="true"></i> Brand
  							</a>
  						</h5>
  					</div>
  					<div id="collapse0" class="panel-collapse collapse in" >
  						<ul class="list-group">
  							<li class="list-group-item">
  								<div class="checkbox">
  									<label>
  										<input type="radio" value="">
  										Banana Boat
  									</label>
  								</div>
  							</li>
  							<li class="list-group-item">
  								<div class="checkbox" >
  									<label>
  										<input type="radio" value="">
  										La Roche - Posay
  									</label>
  								</div>
  							</li>
  							<li class="list-group-item">
  								<div class="checkbox"  >
  									<label>
  										<input type="radio" value="">
  										Neutrogena
  									</label>
  								</div>
  							</li>
  							<li class="list-group-item">
  								<div class="checkbox"  >
  									<label>
  										<input type="radio" value="">
  										Nivea
  									</label>
  								</div>
  							</li>
  						</ul>
  					</div>

  					<div class="" style=" margin-top:20px;" >
  						<h5 class="panel-title">
  							<a data-toggle="collapse" href="#collapse1">
  								<i class="indicator fa fa-caret-down" aria-hidden="true"></i>Part of body
  							</a>
  						</h5>
  					</div>
  					<div id="collapse1" class="panel-collapse collapse in" >
  						<ul class="list-group">
  							<li class="list-group-item">
  								<div class="checkbox">
  									<label>
  										<input type="radio" value="">
  										Only Face
  									</label>
  								</div>
  							</li>
  							<li class="list-group-item">
  								<div class="checkbox" >
  									<label>
  										<input type="radio" value="">
  										All Body
  									</label>
  								</div>
  							</li>
  						</ul>
  					</div>

  					<div class="" style=" margin-top:20px;" >
  						<h5 class="panel-title">
  							<a data-toggle="collapse" href="#collapse2"><i class="indicator fa fa-caret-down" aria-hidden="true"></i>SPF</a>
  						</h5>
  					</div>
  					<div id="collapse2" class="panel-collapse collapse in">
  						<ul class="list-group">
  							<li class="list-group-item">
  								<div class="checkbox">
  									<label>
  										<input type="radio" value="">
  										15+
  									</label>
  								</div>
  							</li>
  							<li class="list-group-item">
  								<div class="checkbox" >
  									<label>
  										<input type="radio" value="">
  										30+
  									</label>
  								</div>
  							</li>
  							<li class="list-group-item">
  								<div class="checkbox"  >
  									<label>
  										<input type="radio" value="">
  										50+
  									</label>
  								</div>
  							</li>
                <li class="list-group-item">
  								<div class="checkbox"  >
  									<label>
  										<input type="radio" value="">
  										80+
  									</label>
  								</div>
  							</li>
  						</ul>
  					</div>

  					<div class="" style=" margin-top:20px;">
  						<h5 class="panel-title">
  							<a data-toggle="collapse" href="#collapse3"><i class="indicator fa fa-caret-right" aria-hidden="true"></i>Product Type</a>
  						</h5>
  					</div>
  					<div id="collapse3" class="panel-collapse collapse">
  						<ul class="list-group">
  							<li class="list-group-item">
  								<div class="checkbox">
  									<label>
  										<input type="radio" value="">
  										Cream Lotion
  									</label>
  								</div>
  							</li>
                <li class="list-group-item">
                  <div class="checkbox">
                    <label>
                      <input type="radio" value="">
                      Fluid
                    </label>
                  </div>
                </li>
                <li class="list-group-item">
                  <div class="checkbox">
                    <label>
                      <input type="radio" value="">
                      Roll on
                    </label>
                  </div>
                </li>
                <li class="list-group-item">
                  <div class="checkbox">
                    <label>
                      <input type="radio" value="">
                      Spray
                    </label>
                  </div>
                </li>
              </ul>
            </div>

                <div class="" style=" margin-top:20px;">
                  <h5 class="panel-title">
                    <a data-toggle="collapse" href="#collapse4"><i class="indicator fa fa-caret-right" aria-hidden="true"></i>Ingredient</a>
                  </h5>
                </div>
                <div id="collapse4" class="panel-collapse collapse">
                  <ul class="list-group">
                    <li class="list-group-item">
                      <div class="checkbox">
                        <label>
                          <input type="radio" value="">
                          ....
                        </label>
                      </div>
                    </li>
                    <li class="list-group-item">
                      <div class="checkbox">
                        <label>
                          <input type="radio" value="">
                          ....
                        </label>
                      </div>
                    </li>
                  </ul>
                </div>

                    <div class="" style=" margin-top:20px;" >
                      <h5 class="panel-title">
                        <a data-toggle="collapse" href="#collapse5"><i class="indicator fa fa-caret-right" aria-hidden="true"></i>Skin Type</a>
                      </h5>
                    </div>
                    <div id="collapse5" class="panel-collapse collapse">
                      <ul class="list-group">
                        <li class="list-group-item">
                          <div class="checkbox">
                            <label>
                              <input type="radio" value="">
                              Normal Skin
                            </label>
                          </div>
                        </li>
                        <li class="list-group-item">
                          <div class="checkbox">
                            <label>
                              <input type="radio" value="">
                              Dry Skin
                            </label>
                          </div>
                        </li>
                        <li class="list-group-item">
                          <div class="checkbox">
                            <label>
                              <input type="radio" value="">
                              Oily Skin
                            </label>
                          </div>
                        </li>
                        <li class="list-group-item">
                          <div class="checkbox">
                            <label>
                              <input type="radio" value="">
                              Combination Skin
                            </label>
                          </div>
                        </li>
                        <li class="list-group-item">
                          <div class="checkbox">
                            <label>
                              <input type="radio" value="">
                              Sensitive Skin
                            </label>
                          </div>
                        </li>
                      </ul>
                    </div>


  					</div>
  				</div>
  			</div>
  		</div>
  	</div>
  </div>

   </div>
</div>
    </div>

<div class="VerticalLine3"></div>


                <br>
<!-- Button -->

                <div class="buttonReset_Search">
                <input type="submit" value="Reset" class="btn btn-light" id="buttonResetSearch" >&nbsp&nbsp
                <input type="submit" value="Search" class="btn btn-light" id="buttonResetSearch" >
                </div>

                <br><br>


</div>
</main>
</div>
</div>
