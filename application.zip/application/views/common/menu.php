<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

    <div class="menu">
      <div class="">
        Web Application Level 1 (20 ชั่วโมง)
      </div>
       <ul>
         
         <li>System Config</li>
         <li>Routing Controller</li>
         <li><a href="<?=$cParameterRoute?>">Routing Controller With Parameter</a></li>
         <li>การสร้างและเรียกใช้งาน Controller</li>
         <li>การโหลดหน้า View แบบ Single View</li>
         <li>การโหลดหน้า View แบบ Mullti View</li>
         <li>การสร้าง HTML View</li>
         <li>การโหลด CSS และ JS เพื่อใช้งานใน View</li>
         <li>การส่งค่าจาก View ไปยัง Controller</li>
         <li>Call Controllor In Controllor</li>
         <li>Application Form</li>
         <li>GET Data With Form Data</li>
         <li>Call Controllor With Parameter</li>
         <li>Get Parameter With URL Controller</li>
       </ul>
    </div>

  </body>
</html>
