<!-- div outside -->

<div class="containerpage7">
  <p style="font-size:12px; color:#CCCBCA;">
    <a style="color:#CCCBCA;" href="<?=base_url();?>home">home</a>
    <a style="color:#CCCBCA;" href="<?=base_url();?>login"> > Login & Register</a>
    <a style="color:#CCCBCA;" href="<?=base_url();?>createaccount"> > Create Account</a>
    </p>
  </div>

<!-- Start Form -->

  <div class="container-fluid">
  <div class="row">
  <main class="col-sm-8 ml-sm-auto col-md-10 pt-3" role="main">

<!-- main content -->

  <div class="row">
  <div class="col-md-6" style="padding-top:40px;">
      <h4 style="font-weight:bold;"><img src="<?=base_url()?>application/assets/images/arrow2.jpg" style="width:20px;"> &nbsp  Create Account</h4><br><br>
      <!-- <div class"LoginLeft" style="margin-top:50px;"> -->
      <p style="line-height:1%; font-size: 17px;"> Fill in your detail </p>


<!-- Form -->
    <form method="post" id="register_form" action="<?=base_url()?>completeregister" enctype="multipart/form-data">
      <!-- action="<?=base_url()?>register" -->
      <div class="form-group col-md-6 mb-3" style="margin-top:30px; margin-left:-13px;">
        <label for="createName">Your Name *</label>
        <input type="text" class="form-control" id="createName" name="createName" placeholder="Enter Your Name">
        <!-- value="<?=$registerDetails->Customer_?> -->
      </div>

      <div class="form-group col-md-6 mb-3" style="margin-left:-13px;">
        <label for="createEmail">E-mail Address *</label>
        <input type="email" class="form-control" id="createEmail" name="createEmail" aria-describedby="emailHelp" placeholder="Enter email">
      </div>

      <div class="form-group col-md-6 mb-3" style=" margin-left:-13px;">
        <label for="createPassword">Password *</label>
        <input type="password" class="form-control" id="createPassword" name="createPassword" placeholder="Password">
        <small id="passwordHelp" class="form-text text-muted">( at least 8 characters )</small>
      </div>
      <p></p>

  </div>
    <div class="VerticalLine">
    </div>
    <div class="col-md-6"><br>

<!-- account right-->
            <div style="margin-top:95px;">
              <div class="form-group col-md-6 mb-3" style=" margin-left:-13px;">
                <label for="confirmPassword">Confirm Password *</label>
                <input type="password" class="form-control" name="confirmPassword" id="confirmPassword" placeholder="Password">
                <small id="passwordHelp" class="form-text text-muted">( at least 8 characters )</small>
                <p></p>
                <!-- <a href="<?=base_url();?>#"><button type="submit" class="btn btn-light" style="margin-left:0px; color: white; background-color:#F89C1C; " >Register</button></a> -->
                <input type="submit" value="Register" class="btn btn-light" id="buttonRegister" style="margin-left:0px;" >

                <!-- id="btn-register" -->

                <p style="font-size:12px; margin-top: 20px;">By creating an account, you agree <br>that you have read and accepted our <br> Conditions of Use and Privacy Notice.</p>
              </div>
            </div>
      </div>
  </form>
    <!-- end row -->
  </div>
  <!-- end container  -->
  </div>
</main>
</div>
</div>
