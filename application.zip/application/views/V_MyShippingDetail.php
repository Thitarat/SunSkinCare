<!-- div outside -->

<div class="containerpage7">
  <p style="font-size:12px; color:#CCCBCA;">
    <a style="color:#CCCBCA;" href="<?=base_url();?>home">home</a>
    <a style="color:#CCCBCA;" href="<?=base_url();?>myaccount"> > My Account</a>
    <a style="color:#CCCBCA;" href="<?=base_url();?>myshippingdetail"> > My Shipping Detail</a>

    </p>
  </div>

<!-- Start Form -->



  <div class="container-fluid">
  <div class="row">
    <main class="col-sm-8 ml-sm-auto col-md-10 pt-3" role="main">
<!-- main content -->
    <div class="row">
    <div class="col-md-6" style="padding-top:40px;">
        <h4 style="font-weight:bold;"><img src="<?=base_url()?>application/assets/images/arrow2.jpg" style="width:20px;"> &nbsp  My Account</h4><br><br>

<!-- Title -->

<div class="col-md-6 mb-3" style="margin-top:10px; margin-left:-30px;">
  <div>
  <a href="<?=base_url();?>myaccount" class="nav-link"  id="button1"><h5 style="font-weight:bold;">My Account Profile</h5></a>

  <img id="buttonShip" src="<?=base_url()?>application/assets/images/arrow5.jpg" style="width:15px; margin-left:88px; margin-top:18px; display:block;" >
  <a href="<?=base_url();?>myshippingdetail" class="nav-link" id="button1_1" onclick="showImage();" ><h5 style="font-weight:bold;">My Shipping Detail</h5></a>

  <img id="buttonShip" src="<?=base_url()?>application/assets/images/arrow5.jpg" style="width:15px; margin-left:88px; margin-top:18px; display:none;">
  <a href="<?=base_url();?>mypaymentinfo" class="nav-link"  id="button1" onclick="showImage();"><h5 style="font-weight:bold;" >My Payment Info.</h5></a>

  <img id="buttonShip" src="<?=base_url()?>application/assets/images/arrow5.jpg" style="width:15px; margin-left:88px; margin-top:18px; display:none;">
  <a href="<?=base_url();?>myorders" class="nav-link" id="button1" onclick="showImage();"><h5 style="font-weight:bold;">My Orders</h5></a>

   </div>
</div>
    </div>

<div class="VerticalLine2"></div>

<form method="post" id="" action="<?=base_url()?>" enctype="multipart/form-data">

  <div class="form-group col-md-24"><br><br>


<!--  right side-->
        <div style="margin-top:95px;margin-left:-200px;" >
          <div class="form-group col-md-7 mb-3" >
            <p style="font-size: 20px; font-weight:bold; margin-left:-12px;">Create Address</p>
            <p style="font-size:12px; margin-left:-12px; line-height:0;">* required field </p>

            <div style="margin-top:45px;">
              <div class="form-row" >
              <div class="col-md-5 mb-3" style=" margin-left:-13px;">
                  <label for="createName">My First Name *</label>
                  <input type="text" class="form-control" id="createName" name="createName" placeholder="Enter first name">
              </div>
&nbsp
              <div class="col-md-6 mb-3" style="">
                  <label for="createLastName">Last Name</label>
                  <input type="text" class="form-control" id="createLastName" name="createLastName" placeholder="Enter last name">
              </div>
              </div>

              <div class="form-group col-md-12 mb-3" style=" margin-left:-27px; margin-top:10px;">
                  <label for="createAddress">My Address *</label>
                  <input type="text" class="form-control" id="createAddress" name="createAddress" placeholder="Enter address">
              </div>

              <div class="form-row" >
              <div class="col-md-6 mb-3" style=" margin-left:-13px; margin-top:10px;">
                <label >Country *</label>
                <input type="text" class="form-control" id="createCountry" name="createCountry" placeholder="">
              </div>

&nbsp
              <div class="col-md-5 mb-3" style=" margin-top:10px;">
                <label >State</label>
                <select id="inputState" class="form-control">
                  <option selected>Choose...</option>
                  <option>NSW</option>
                  <option>QLD</option>
                  <option>VIC</option>
                  <option>SA</option>
                  <option>TAS</option>
                  <option>WA</option>
                  <option>ACT</option>
                  <option>None</option>
                </select>
              </div>

              <div class="col-md-7 mb-3" style=" margin-left:-13px; margin-top:10px;">
                <label >City *</label>
                <input type="text" class="form-control" id="createCity" name="createCity" placeholder="">
              </div>
&nbsp
              <div class="col-md-4 mb-3" style="  margin-top:10px;">
                <label >Postcode *</label>
                <input type="text" class="form-control" id="createCode" name="createCode" placeholder="">
              </div>
              </div>
              <div class="form-group col-md-12 mb-3" style=" margin-left:-27px; margin-top:25px;">
                <label >Contact Number *</label>
                <input type="tel" class="form-control" id="createNumber" name="createNumber" placeholder="">
              </div>


                <br><br>
<!-- Button -->

                <div class="buttonSaveCancel">
                <input type="submit" value="Cancel" class="btn btn-light"  >&nbsp&nbsp
                <input type="submit" value="Save" class="btn btn-light" id="saveButton" >
                </div>

                <br><br>

              </div>

            </div>
          </div>


  </div>
</form>

</div>
</main>
</div>
</div>
