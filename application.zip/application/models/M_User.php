<?php
defined('BASEPATH' OR exit('No direct script access allowed'));
class M_User extends CI_Model
{
      function __construct()
      {
          parent::__construct();
      }

      public function mRegister($registerDetails){
         if ($this->db->insert('customers',$registerDetails)){
           return 'Register completed';
         }else{
           return 'Register failed';
         }
      }

      public function mLogin($username, $convertedPassword){
        $SQL = "SELECT Customer_ID,
                       Customer_Name,
                       Customer_Email
                FROM customers
                WHERE Customer_Email = '$username' AND Customer_Password = '$convertedPassword'";
        $query = $this->db->query($SQL);
         if ($query->num_rows() > 0) {
           return $query->row();
         }else{
           return 'empty';
         }
      }
}
