<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mtest extends CI_Model {

	function __construct()
  {
          parent::__construct();
					$this->load->database();
  }

	public function index()
	{

		 $data  = array('user' => 'root', 'pass'=>'1234' );
		 return  $this->db->insert('users',$data);

	}

	// function musers(){
	// 	    $this->db->select('user, pass');
	// 			// $this->db->where('user', 'root1');
	// 			// $this->db->where('pass', '1234');
  //       $query = $this->db->get('users');
	// 			$Result = $query->result();
	// 		  return $Result;
	// }

	function musers(){
		    $this->db->select('user, pass , groupname');
				// $this->db->where('user', 'root1');
				// $this->db->where('pass', '1234');
        $query = $this->db->from('users');
				$query = $this->db->join('user_group','user_group.groupid=users.groupid');
				$query = $this->db->get();

				$Result = $query->result();
			  return $Result;
	}
}
