$(document).ready(function(){

  $('#btn-register').click(function(){
      createUser();
  });

});

function createUser() {

  if ($('#createName').val().length == 0) {
          $('#createName').focus();
          alert('Name missing');
      } else if ($('#createEmail').val().length == 0) {
              $('#createEmail').focus();
              alert('Email missing');
      } else if ($('#createPassword').val().length == 0){
              $('#createPassword').focus();
              alert('Password is missing');
      } else if ($('#confirmPassword').val().length == 0){
              $('#confirmPassword').focus();
              alert('Password is incorrect');
     }else{
       console.log('validate done');                      //validate process
          var createName = $('#createName').val();
          var createEmail = $('#createEmail').val();
          var createPassword = $('#createPassword').val();
          var confirmPassword = $('#confirmPassword').val();
         console.log(createName + createEmail + createPassword + confirmPassword);
       }
          $.ajax({
            url:'register',
            data:{createName:createName,
            createEmail:createEmail,
            createPassword:createPassword},
            method:"POST"
          })

          .done(function(tResult){
          console.log('done');                        //check processing
            if (tResult == 'error') {
               alert('!Cannot register.');
             }else{
                           // clear form
            $('#createName').val('');
            $('#createEmail').val('');
                        $('#createPassword').val('');
                        $('#confirmPassword').val('');
                        alert('Thank you ' + createName + ', your account successfully created !');
              }
            })

          .fail(function(jqXHR, textStatus){
                  alert('Error:'+ jqXHR +' '+ textStatus);
          });
}
