<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_Home extends CI_Controller {

	function __construct()
  {
          parent::__construct();
          $this->load->helper('url');

  }

	public function index()
	{
      $this->load->view('template/Header');
      $this->load->view('V_Home');
      $this->load->view('template/Footer');
	}
}
