<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ctest1 extends CI_Controller {



	public function index()
	{

    return "Resporn From Controller Test 1";
	}
}
