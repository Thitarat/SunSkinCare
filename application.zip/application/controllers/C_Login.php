<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_Login extends CI_Controller {

	function __construct()
  {
          parent::__construct();
          $this->load->helper('url');
          $this->load->model('M_User', 'm_user');
					$this->load->library('session');
  }

	public function index()
	{


      $this->load->view('template/Header');
      $this->load->view('V_Login');
      $this->load->view('template/Footer');
	}

	public function login(){
// receive View Login form
					$username = $this->input->post('loginEmail');
					$password = $this->input->post('loginPassword');
					$convertedPassword = md5($password);
// form detail -> model Login
					$customerInfo = $this->m_user->mLogin($username,$convertedPassword);

					$customerData = array('Customer_ID' => $customerInfo->Customer_ID,
																'Customer_Name' => $customerInfo->Customer_Name,
																'Customer_Email' => $customerInfo->Customer_Email);

				  $this->session->set_userdata($customerData);

					$this->load->view('template/Header');
					$this->load->view('V_Login');
					$this->load->view('template/Footer');

					redirect('myaccount');
	}
	public function logout(){
		$this->session->sess_destroy();
		// $this->session->unset_userdata('customerNameSess');
		redirect('home');
	}
}
