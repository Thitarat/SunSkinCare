<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_MyAccount extends CI_Controller {

	function __construct()
  {
          parent::__construct();
          $this->load->helper('url');
					$this->load->library('session');
  }

	public function index()
	{
			$customerEmail = $this->session->userdata('Customer_Email');

			// echo $this->session->userdata('Customer_ID');
			if ($this->session->has_userdata('Customer_ID')){
				$customerID = $this->session->userdata('Customer_ID');
			}else{
				$customerID = '';
			}

			if ($this->session->has_userdata('Customer_Name')){
				$customerName = $this->session->userdata('Cutomer_Name');
			}else{
				$customerName ='';
			}

			if(isset($customerID)){
				if ($customerID == ''){
					redirect('login');
				}
			}

			$csInfo = array('customerEmail' => $customerEmail,
												'customerName' => $customerName,
												'cutomerID' => $customerID);

      $this->load->view('template/Header');
      $this->load->view('V_MyAccount',$csInfo);
      $this->load->view('template/Footer');
	}
}
