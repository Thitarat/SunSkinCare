<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_CreateAccount extends CI_Controller {

	function __construct()
  {
          parent::__construct();
          $this->load->helper('url');
          $this->load->model('M_User', 'm_user');
  }

	public function index()
	{
      $this->load->view('template/Header');
      $this->load->view('V_CreateAccount');
      $this->load->view('template/Footer');
	}

  public function CompleteRegisterUser(){

    //receive customer register details
    $registerName = $this->input->post('createName');
    $registerEmail = $this->input->post('createEmail');
    $registerPassword = $this->input->post('createPassword');

		$convertedPassword = md5($registerPassword);

    $registerDetails =  array('Customer_Name' => $registerName,
                              'Customer_Email' => $registerEmail,
                              'Customer_Password' => $convertedPassword,
                              );

    $saveRegisterDetais = $this->m_user->mRegister($registerDetails);

    // echo $saveRegisterDetais;

    $this->load->view('template/Header');
    $this->load->view('V_CompleteRegister',$registerDetails);
    $this->load->view('template/Footer');

  }

}
