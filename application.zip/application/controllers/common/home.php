<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

  function __construct()
  {
          parent::__construct();
  }

	public function index()
	{
       $this->load->helper('url');

       $para1 = 1;
       $para2 = 'Peter';

       //controller  common/home/cParameter2
       $data['cParameterRoute'] = $this->config->base_url()."sentpara/".$para1."/".$para2;


		   $this->load->view('common/menu',$data);
	}

  public function cParameter2($id="",$name=""){
     echo $id.'=>'.$name;
  }
}
