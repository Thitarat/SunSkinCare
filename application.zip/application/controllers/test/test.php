<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller {

  function __construct()
  {
          parent::__construct();
  }

	public function index()
	{
       $this->load->helper('url');
       $this->load->model('test/mtest','TestModels');
       $this->load->controller('test1/ctest1','Test1Controller');

       $data['CTest1'] = $this->Test1Controller->index();
       $data['MTest'] = $this->TestModels->musers();
       $data['CTest'] = 'Data From Current Controller';

		   $this->load->view('test/test',$data);
	}

  public function users(){

         $this->load->model('test/mtest','TestModels');

  }
}
