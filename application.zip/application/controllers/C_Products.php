<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_Products extends CI_Controller {

	function __construct()
  {
          parent::__construct();
          $this->load->helper('url');

  }

	public function index()
	{
      $this->load->view('template/Header');
      $this->load->view('V_Products');
      $this->load->view('template/Footer');
	}
}
