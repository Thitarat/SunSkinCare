#######################
Downloading CodeIgniter
#######################

-  `CodeIgniter v3.2.0-dev (Current version) <https://codeload.github.com/bcit-ci/CodeIgniter/zip/develop>`_
-  `CodeIgniter v3.1.3-dev <https://codeload.github.com/bcit-ci/CodeIgniter/zip/3.1-stable>`_
-  `CodeIgniter v3.1.2 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/3.1.2>`_
-  `CodeIgniter v3.1.1 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/3.1.1>`_
-  `CodeIgniter v3.1.0 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/3.1.0>`_
-  `CodeIgniter v3.0.6 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/3.0.6>`_
-  `CodeIgniter v3.0.5 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/3.0.5>`_
-  `CodeIgniter v3.0.4 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/3.0.4>`_
-  `CodeIgniter v3.0.3 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/3.0.3>`_
-  `CodeIgniter v3.0.2 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/3.0.2>`_
-  `CodeIgniter v3.0.1 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/3.0.1>`_
-  `CodeIgniter v3.0.0 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/3.0.0>`_
-  `CodeIgniter v2.2.3 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/2.2.3>`_
-  `CodeIgniter v2.2.2 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/2.2.2>`_
-  `CodeIgniter v2.2.1 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/2.2.1>`_
-  `CodeIgniter v2.2.0 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/2.2.0>`_
-  `CodeIgniter v2.1.4 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/2.1.4>`_
-  `CodeIgniter v2.1.3 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/2.1.3>`_
-  `CodeIgniter v2.1.2 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/2.1.2>`_
-  `CodeIgniter v2.1.1 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/2.1.1>`_
-  `CodeIgniter v2.1.0 <https://codeload.github.com/bcit-ci/CodeIgniter/zip/v2.1.0>`_

******
GitHub
******

`Git <http://git-scm.com/about>`_ is a distributed version control system.

Public Git access is available at `GitHub <https://github.com/bcit-ci/CodeIgniter>`_.
Please note that while every effort is made to keep this code base
functional, we cannot guarantee the functionality of code taken from
the develop branch.

Beginning with version 2.0.3, stable versions are also available via `GitHub Releases <https://github.com/bcit-ci/CodeIgniter/releases>`_.
