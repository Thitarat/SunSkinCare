<!-- div outside -->

<div class="containerpage7">
  <p style="font-size:12px; color:#CCCBCA;">
    <a style="color:#CCCBCA;" href="<?=base_url();?>home">home</a>
    <a style="color:#CCCBCA;" href="<?=base_url();?>myaccount"> > My Account</a>
    <a style="color:#CCCBCA;" href="<?=base_url();?>myaccount"> > My Account Profile</a>

    </p>
  </div>

<!-- Start Form -->



  <div class="container-fluid">
  <div class="row">
    <main class="col-sm-8 ml-sm-auto col-md-10 pt-3" role="main">
<!-- main content -->
    <div class="row">
    <div class="col-md-6" style="padding-top:40px;">
        <h4 style="font-weight:bold;"><img src="<?=base_url()?>application/assets/images/arrow2.jpg" style="width:20px;"> &nbsp  My Account</h4><br><br>

<!-- Title -->

<div class="col-md-6 mb-3" style="margin-top:10px; margin-left:-30px;">
  <div>
  <a href="<?=base_url();?>myaccount" class="nav-link"  id="button1_1"><h5 style="font-weight:bold;">My Account Profile</h5></a>

  <img id="buttonShip" src="<?=base_url()?>application/assets/images/arrow5.jpg" style="width:15px; margin-left:88px; margin-top:18px; display:none;" >
  <a href="<?=base_url();?>myshippingdetail" class="nav-link" id="button1" onclick="showImage();" ><h5 style="font-weight:bold;">My Shipping Detail</h5></a>

  <img id="buttonShip" src="<?=base_url()?>application/assets/images/arrow5.jpg" style="width:15px; margin-left:88px; margin-top:18px; display:none;">
  <a href="<?=base_url();?>mypaymentinfo" class="nav-link"  id="button1" onclick="showImage();"><h5 style="font-weight:bold;" >My Payment Info.</h5></a>

  <img id="buttonShip" src="<?=base_url()?>application/assets/images/arrow5.jpg" style="width:15px; margin-left:88px; margin-top:18px; display:none;">
  <a href="<?=base_url();?>myorders" class="nav-link" id="button1" onclick="showImage();"><h5 style="font-weight:bold;">My Orders</h5></a>

   </div>
</div>
    </div>

<div class="VerticalLine2"></div>

<form method="post" id="" action="<?=base_url()?>" enctype="multipart/form-data">

  <div class="form-group col-md-20"><br><br>

<!--  right side-->
        <div style="margin-top:95px;margin-left:-200px;" >
          <div class="form-group col-md-10 mb-3" >
            <p style="font-size: 20px; font-weight:bold; margin-left:-12px;">Account Setting</p>
            <p style="font-size:12px; margin-left:-12px; line-height:0;">* required field </p>

            <div style="margin-top:45px;">
              <div class="row" >
              <div class="col-md-6 mb-3" style=" margin-left:-13px;">
                  <label for="createName">My First Name *</label>
                  <input type="text" class="form-control" id="createName" name="createName" placeholder="Enter first name">
              </div>

              <div class="col-md-7 mb-3" style="margin-left:-20px;">
                  <label for="createLastName">Last Name</label>
                  <input type="text" class="form-control" id="createLastName" name="createLastName" placeholder="Enter last name">
              </div>
              </div>

              <div class="form-group col-md-14 mb-3" style=" margin-left:-13px; margin-top:15px;">
                  <label >E-mail Address *</label>
                  <input type="email" class="form-control" id="createEmail" name="createEmail" placeholder="Enter email" value="<?=$customerEmail?>">
              </div>

              <div class="form-group col-md-14 mb-3" style=" margin-left:-13px; margin-top:25px;">
                <label for="createPassword">Password *</label>
                <input type="password" class="form-control" id="createPassword" name="createPassword" placeholder="Password">
                <small id="passwordHelp" class="form-text text-muted">( at least 8 characters )</small>
              </div>

              <div class="form-group col-md-14 mb-3" style=" margin-left:-13px; margin-top:25px;">
                <label for="confirmPassword">Confirm Password *</label>
                <input type="password" class="form-control" name="confirmPassword" id="confirmPassword" placeholder="Password">
                <small id="passwordHelp" class="form-text text-muted">( at least 8 characters )</small>
              </div>


<!-- Radios -->
              <br>
    <fieldset class="form-group">
    <div class="row">
      <legend class="col-form-label col-sm-7 pt-0" style="font-weight:bold;font-size: 17px; margin-left:-12px" >In Depth about Me</legend>
      <!-- <p style="font-weight:bold;font-size: 17px; margin-left:-25px">In Depth about Me</p>
      <p style="font-size: 15px; ">My Skin Type</p> -->
      <br><br>
      <legend class="col-form-label col-sm-6 pt-0" style="font-size: 15px; margin-left:-12px" >My Skin Type</legend>
      <div class="row-sm-6">
        <div class="form-check">
          <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
          <label class="form-check-label" for="gridRadios1">
            Type1 : Normal Skin
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios2" value="option2">
          <label class="form-check-label" for="gridRadios2">
            Type2 : Dry Skin
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios3" value="option3" >
          <label class="form-check-label" for="gridRadios3">
            Type3 : Oily Skin
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios4" value="option4">
          <label class="form-check-label" for="gridRadios4">
            Type4 : Combination Skin
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios5" value="option5" >
          <label class="form-check-label" for="gridRadios5">
            Type5 : Sensitive Skin
          </label>
        </div>
      </div>
    </div>
  </fieldset>
                <br><br>
<!-- Button -->

                <div class="buttonSaveCancel">
                <input type="submit" value="Cancel" class="btn btn-light"  >&nbsp&nbsp
                <input type="submit" value="Save" class="btn btn-light" id="saveButton" >
                </div>

                <br><br>

              </div>

            </div>
          </div>


  </div>
</form>

</div>
</main>
</div>
</div>
