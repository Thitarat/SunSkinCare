CodeIgniter

<a href="<?=$Lesson_URL?>">Lesson</a>
