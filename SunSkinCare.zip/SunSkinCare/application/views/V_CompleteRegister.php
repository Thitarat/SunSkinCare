

<div class="col-md-12" style="text-align:center; padding-top:150px;">
          <img src="<?=base_url()?>application/assets/images/arrow4.jpg" style="width:20px;">
          <p style="margin-top:18px;">Your register is successful</p>
          <h4 style="font-weight:bold; line-height:1%;">Thank you to be a part of us</h4>
          <br>
          <a class="nav-link nav-item" href="<?=base_url();?>myaccount" style="font-size:17px; "> go to my account </a>
          <img src="<?=base_url()?>application/assets/images/BackgroundComplete.jpg" style="width:105%;margin-left:-20px; align-items:back;">
</div>
