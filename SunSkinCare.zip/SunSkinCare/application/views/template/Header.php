<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title></title>
    <!-- Bootstrap core CSS -->
    <link href="<?=base_url()?>application/assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?=base_url()?>application/assets/css/album.css" rel="stylesheet">
    <!-- My custom css -->
    <link href="<?=base_url()?>application/assets/css/common.css" rel="stylesheet">
    <link href="<?=base_url()?>application/assets/css/common2.css" rel="stylesheet">
    <!-- Bootstrap core2 CSS -->
    <link href="<?=base_url()?>application/assets/css/bootstrap.css" rel="stylesheet">

    <!-- filter search -->
    <link rel="stylesheet" href="<?=base_url()?>https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">
    <link href="<?=base_url()?>//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link href="<?=base_url()?>application/assets/css/filterSearch.css" rel="stylesheet">




  </head>
  <body>
    <!-- <nav class="navbar navbar-light justify-content-between"> -->
    <div class="containerpage">
    <nav class="navbar navbar-expand-lg navbar-light justify-content-between" >
      <a class="navbar-brand" href="<?=base_url();?>home">
        <img class="" src="<?=base_url()?>application/assets/images/Logo.jpg" style="width:250px;">
      </a>
      <!-- nav bar 1 log in-->
      <ul class="navbar-nav">
        <li class="nav-item" style="text-align:center;">
          <div style="position:relative; bottom:-15px ">
           <a class="nav-link" href="<?=base_url();?>login"><i class="fa fa-sign-in" aria-hidden="true" style="align-items:center;"></i>Log in & Register</a>
           <!-- data-toggle="modal" data-target="#sModal" -->
         </div>
         </li>
         <li class="nav-item">
           <img src="<?=base_url()?>application/assets/images/Bag.jpg" style="width:65px;">
         </li>
      </ul>
    </nav>
  </div>

    <!-- Line between-->

    <p style="border-top:1.3px solid #CCCBCA; margin-left:320px; margin-right:60px"></p>

    <!-- nav 2 -->

    <nav class="navbar navbar-expand-lg navbar-light justify-content-between">
      <div class="containerpage2" >
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="<?=base_url();?>home">Care Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?=base_url();?>careabout">Care About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?=base_url();?>careproducts">Care Products</a>
        </li>
      </ul>
      </div>
      <div class="containerpage2" >
      <form class="form-inline" >
        <button class="btn btn-link" type="submit" ><img src ="<?=base_url()?>application/assets/images/Searchsun.jpg" style="width:50px;"></button>
        <input class="form-control mr-sm-2" type="search" placeholder="Search Products..." aria-label="Search" >
      </form>
    </div>
    </nav>

    <!-- Bootstrap core JavaScript
       ================================================== -->
       <!-- Placed at the end of the document so the pages load faster -->
       <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
       <script>window.jQuery || document.write('<script src="<?=base_url()?>application/assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
       <script src="<?=base_url()?>application/assets/js/popper.min.js"></script>
       <script src="<?=base_url()?>application/assets/js/bootstrap.min.js"></script>
       <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
       <script src="<?=base_url()?>application/assets/js/vendor/holder.min.js"></script>
       <!-- My custom js -->
