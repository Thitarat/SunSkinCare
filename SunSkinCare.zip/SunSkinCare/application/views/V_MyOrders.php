<!-- div outside -->

<div class="containerpage7">
  <p style="font-size:12px; color:#CCCBCA;">
    <a style="color:#CCCBCA;" href="<?=base_url();?>home">home</a>
    <a style="color:#CCCBCA;" href="<?=base_url();?>myaccount"> > My Account</a>
    <a style="color:#CCCBCA;" href="<?=base_url();?>myorders"> > My Orders</a>

    </p>
  </div>

<!-- Start Form -->



  <div class="container-fluid">
  <div class="row">
    <main class="col-sm-8 ml-sm-auto col-md-10 pt-3" role="main">
<!-- main content -->
    <div class="row">
    <div class="col-md-6" style="padding-top:40px;">
        <h4 style="font-weight:bold;"><img src="<?=base_url()?>application/assets/images/arrow2.jpg" style="width:20px;"> &nbsp  My Account</h4><br><br>

<!-- Title -->

<div class="col-md-6 mb-3" style="margin-top:10px; margin-left:-30px;">
  <div>
  <a href="<?=base_url();?>myaccount" class="nav-link"  id="button1"><h5 style="font-weight:bold;">My Account Profile</h5></a>

  <img id="buttonShip" src="<?=base_url()?>application/assets/images/arrow5.jpg" style="width:15px; margin-left:88px; margin-top:18px; display:none;" >
  <a href="<?=base_url();?>myshippingdetail" class="nav-link" id="button1" onclick="showImage();" ><h5 style="font-weight:bold;">My Shipping Detail</h5></a>

  <img id="buttonShip" src="<?=base_url()?>application/assets/images/arrow5.jpg" style="width:15px; margin-left:88px; margin-top:18px; display:none;">
  <a href="<?=base_url();?>mypaymentinfo" class="nav-link"  id="button1" onclick="showImage();"><h5 style="font-weight:bold;" >My Payment Info.</h5></a>

  <img id="buttonShip" src="<?=base_url()?>application/assets/images/arrow5.jpg" style="width:15px; margin-left:88px; margin-top:18px; display:block;">
  <a href="<?=base_url();?>myorders" class="nav-link" id="button1_1" onclick="showImage();"><h5 style="font-weight:bold;">My Orders</h5></a>

   </div>
</div>
    </div>

<div class="VerticalLine2"></div>

<form method="post" id="" action="<?=base_url()?>" enctype="multipart/form-data">

  <div class="form-group col-md-20"><br><br>

<!--  right side-->
        <div style="margin-top:95px;margin-left:-200px;" >
          <div class="form-group col-md-12 mb-3" >
            <p style="font-size: 20px; font-weight:bold; margin-left:-12px;">My Ordered History</p>
            

            <div style="margin-top:45px;">

              <!-- <div class="col-md-12 mb-3" style=" margin-left:-27px;">
                  <label for="createCardName">Name on Card *</label>
                  <input type="text" class="form-control" id="createCardName" name="createCardName" placeholder="Enter name">
              </div> -->


                <br><br>
<!-- Button -->

                <div class="buttonSaveCancel">
                <input type="submit" value="Delete" class="btn btn-light"  >&nbsp&nbsp
                <input type="submit" value="Clear all" class="btn btn-light" id="saveButton" >
                </div>

                <br><br>

              </div>

            </div>
          </div>


  </div>
</form>

</div>
</main>
</div>
</div>
