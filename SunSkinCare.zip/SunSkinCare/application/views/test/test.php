
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/application/assets/css/style.css">
  </head>
  <body>
   <img src="<?php echo base_url(); ?>application/assets/images/001.jpg" alt="">
    <div class="">
    <?php echo $CTest; ?>
    </div>

    <div class="">
        <?php echo $CTest1; ?>
    </div>
    <div class="">

    </div>
    <table>
      <tr>
        <th>Username</th>
        <th>Group</th>
      </tr>
      <?php foreach ($MTest as $m) {  ?>
      <tr>
        <td><?php echo $m->user; ?></td>
        <td><?php echo $m->groupname; ?></td>
      </tr>
      <?php }  ?>
    </table>


  </body>
</html>
