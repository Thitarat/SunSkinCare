<div class="containerpage5_about">
  <img src="<?=base_url()?>application/assets/images/Careabout.jpg" style="width:60%; align-items:center; margin-left:auto; margin-right:auto; display:block;">
</div>
